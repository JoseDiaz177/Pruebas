import pandas as pd
import json

def generar_dataset():
    print("UPRATE_2026.xlsx...")
    
    # 1. Leer el archivo saltando el encabezado visual (fila 3)
    df = pd.read_excel("UPRATE_2026.xlsx", header=2)
    
    # 2. Limpiar datos vacíos
    df = df.dropna(subset=['GRUPO'])
    df = df.fillna('')
    
    dataset_lines = []
    
    # 3. Iterar sobre cada fila para crear los ejemplos de entrenamiento
    for index, fila in df.iterrows():
        # Extraer la descripción exacta para usarla como "prompt" del cliente
        descripcion_servicio = str(fila.get('D   e   s   c   r   i   p   t   i   o   n', '')).strip()
        
        if not descripcion_servicio:
            continue
            
        # Simular la instrucción que daría el usuario/cliente
        cantidad = fila.get('Cant/Qty', 1.0)
        unidad = fila.get('Unidad / Unit', '')
        texto_cliente = f"Cotiza el siguiente requerimiento: {descripcion_servicio}. Se requieren {cantidad} {unidad}."
        
        # 4. Mapear las columnas exactas de tu Excel a las 25 llaves JSON
        partida = {
            "grupo": fila.get('GRUPO', ''),
            "desc_grupo": fila.get('DESCRIPCION DE GRUPO', ''),
            "status": fila.get('status', 'AUTO-IA'),
            "client_item": fila.get('Part. Cliente / Client Item', ''),
            "cant": cantidad,
            "unit": unidad,
            "desc_servicio": descripcion_servicio,
            "mhrs": fila.get('MHRS/ UNIT', ''),
            "total_hh": fila.get('Total Horas Hombre', ''),
            "total_mo": fila.get('Total M. O. @ 0', ''),
            "costo_mat": fila.get('Costos de \nMateriales ', ''),
            "subcontratos": fila.get('Subcontratos', ''),
            "adicional": fila.get('Adicional', ''),
            "costo_directo_total": fila.get('Costo Directo Total', ''),
            "utilidad_mo": fila.get('Utilidad M. O. @ ', ''),
            "utilidad_mat": fila.get('Utilidad Materiales @ Servicios incl., en el DOE (SMR)', ''),
            "utilidad_sub": fila.get('% Utilidad Subcontratos @ ', ''),
            "utilidad_adic": fila.get('Utilidad Adicional y Conting. @ ', ''),
            "total_utilidad": fila.get('Total Utilidad ', ''),
            "servicios_incl": fila.get('Servicios incl., en el DOE (SMR)', ''),
            "comision": fila.get('comision', ''),
            "costo_total": fila.get('Costo Total', ''),
            "precio_total_usd": fila.get('Precio Total en USD$               Total Amount $USD', 0.0),
            "precios_ref": fila.get('Precios de Ref.       Reference Price', ''),
            "precio_unitario": fila.get('Precio Unitario      Unit Price', '')
        }
        
        # 5. Estructurar el formato estricto JSONL
        linea = {
            "text_input": texto_cliente,
            "output": json.dumps([partida], ensure_ascii=False)
        }
        dataset_lines.append(json.dumps(linea, ensure_ascii=False))

    # 6. Guardar el archivo JSONL
    with open('dataset_astillero.jsonl', 'w', encoding='utf-8') as f:
        for linea in dataset_lines:
            f.write(linea + '\n')
            
    print(f"¡Éxito! Archivo 'dataset_astillero.jsonl' generado con {len(dataset_lines)} ejemplos listos para el entrenamiento.")

if __name__ == "__main__":
    generar_dataset()