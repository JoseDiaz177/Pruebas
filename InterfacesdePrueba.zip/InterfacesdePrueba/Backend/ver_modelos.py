from google import genai

# Pon tu clave real aquí
gemini_client = genai.Client(api_key="AQ.Ab8RN6KnNVa6jpmrxYiu6sdblVtmZdCHTyBx1DDk8R-CPp883w")

print("Consultando modelos disponibles...\n")

# Obtiene y muestra todos los modelos disponibles para tu API Key
for modelo in gemini_client.models.list():
    print(f"Nombre: {modelo.name}")
    print(f"Descripción: {modelo.description}")
    print("-" * 40)
