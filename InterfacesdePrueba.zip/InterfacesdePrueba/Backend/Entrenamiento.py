from google import genai
import time
import sys

# 1. Autenticación
genai.configure(api_key="AQ.Ab8RN6KnNVa6jpmrxYiu6sdblVtmZdCHTyBx1DDk8R-CPp883w")

# 2. Subir el archivo de entrenamiento (debe estar en formato JSONL)
print("Subiendo dataset a los servidores...")
archivo_dataset = genai.upload_file(path="dataset_astillero.jsonl")
print(f"Archivo subido: {archivo_dataset.name}")

# 3. Configurar e iniciar el ajuste fino
print("Iniciando entrenamiento del modelo Astillero-TNG...")
operacion = genai.create_tuned_model(
    source_model="models/gemini-1.5-flash-001-tuning", # Modelo oficial habilitado para ajuste fino
    training_data=archivo_dataset,
    id="gemini-astillero-tng",
    display_name="Estimador Astillero TNG v1",
    epoch_count=20, # Iteraciones sobre los datos para asegurar el aprendizaje
    batch_size=4,
    learning_rate=0.001
)

# 4. Monitoreo en tiempo real
for update in operacion.wait_bar():
    sys.stdout.write('.')
    sys.stdout.flush()
    time.sleep(10)

# 5. Obtener el ID final
resultado = operacion.result()
print(f"\nEntrenamiento completado.")
print(f"Sustituye 'gemini-3.6-flash' en tu app.py por este nombre: {resultado.name}")
