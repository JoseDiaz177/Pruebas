import pandas as pd
import json

def crear_jsonl_entrenamiento(excel_path, jsonl_path):
    print(f"Leyendo historial desde {excel_path}...")
    
    # 1. Leer el Excel histórico y limpiar nulos
    df = pd.read_excel(excel_path)
    df = df.fillna('')
    
    # 2. Definir las 25 llaves exactas que espera tu sistema
    llaves_esperadas = [
        "grupo", "desc_grupo", "status", "client_item", "cant", "unit", 
        "desc_servicio", "mhrs", "total_hh", "total_mo", "costo_mat", 
        "subcontratos", "adicional", "costo_directo_total", "utilidad_mo", 
        "utilidad_mat", "utilidad_sub", "utilidad_adic", "total_utilidad", 
        "servicios_incl", "comision", "costo_total", "precio_total_usd", 
        "precios_ref", "precio_unitario"
    ]
    
    dataset_lines = []
    
    # 3. Agrupar las filas por proyecto/cotización
    grupos = df.groupby(['id_proyecto', 'requerimiento_cliente'])
    
    for (id_proy, requerimiento), filas in grupos:
        lista_partidas = []
        
        # Construir el JSON de salida con las partidas de ese proyecto
        for _, fila in filas.iterrows():
            partida = {}
            for llave in llaves_esperadas:
                # Si la columna existe en el Excel, toma su valor; si no, string vacío
                partida[llave] = fila[llave] if llave in fila else ""
            lista_partidas.append(partida)
        
        # 4. Formatear la línea para el JSONL (Entrada vs Salida)
        # json.dumps convierte el arreglo a string (requerimiento estricto del fine-tuning)
        linea = {
            "text_input": requerimiento,
            "output": json.dumps(lista_partidas, ensure_ascii=False)
        }
        dataset_lines.append(json.dumps(linea, ensure_ascii=False))
        
    # 5. Guardar el archivo JSONL
    with open(jsonl_path, 'w', encoding='utf-8') as f:
        for linea in dataset_lines:
            f.write(linea + '\n')
            
    print(f"¡Éxito! Dataset creado con {len(dataset_lines)} ejemplos de entrenamiento en {jsonl_path}")

# Ejecutar la función
if __name__ == '__main__':
    crear_jsonl_entrenamiento('UPRATE_2026.xlsx', 'dataset_astillero.jsonl')


