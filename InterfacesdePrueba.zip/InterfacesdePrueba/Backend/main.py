from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from Matriz import PROMPT_RFQ, PROMPT_TECNICO, clasificar_servicio
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import pandas as pd
from google import genai
from dotenv import load_dotenv
import io
from typing import Optional
import os 
import pymupdf
import json 
import re
import numpy as np
import pyodbc
from google.genai import types
import asyncio

# Modelo para recibir los datos hacia SQL
class SolicitudCotizacion(BaseModel):
    eslora: float
    trabajos: list[dict]

load_dotenv() # Carga las variables del archivo .env

client = genai.Client(api_key=("AQ.Ab8RN6LRsYR4Fv3W_5Zl5iDh6iDmxjROPvXKN6PdEvxV0cdZGQ"))

app = FastAPI(title="API de Cotización Automatizada - Astillero")

app.add_middleware(
    CORSMiddleware, 
    allow_origins=["*"], # Permite que tu HTML local se conecte
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modelo de datos para la validación del Frontend (Vista 2)
class DatosBarcoConfirmados(BaseModel):
    cliente: str
    proyecto: str
    eslora: float
    manga: float
    puntal: float

@app.post("/api/extraer-datos-pdf")
async def extraer_datos_pdf(
    archivo_rfq: Optional[UploadFile] = File(None),
    archivo_tecnico: Optional[UploadFile] = File(None)
):
    # Validar que al menos manden un archivo
    if not archivo_rfq and not archivo_tecnico:
        raise HTTPException(status_code=400, detail="Debes subir al menos un archivo PDF.")
    
    datos_finales = {}

    # ==========================================
    # 1. PROCESAMIENTO DEL RFQ (Si se subió)
    # ==========================================
    if archivo_rfq and archivo_rfq.filename.endswith('.pdf'):
        try:
            doc_rfq = pymupdf.open(stream=await archivo_rfq.read(), filetype="pdf")
            texto_rfq = "".join([pagina.get_text() for pagina in doc_rfq])
            
            prompt_rfq_listo = f"{PROMPT_RFQ}\n\n--- TEXTO RFQ ---\n{texto_rfq}"
            res_rfq = client.models.generate_content(model='gemini-3.5-flash', contents=prompt_rfq_listo)
            
            json_rfq_str = res_rfq.text.split("```json")[1].split("```")[0] if "```json" in res_rfq.text else res_rfq.text
            match_rfq = re.search(r'\{.*\}', json_rfq_str, re.DOTALL)
            if match_rfq:
                datos_finales.update(json.loads(match_rfq.group(0)))
        except Exception as e:
            print(f"⚠️ Error procesando el RFQ: {str(e)}")

            await asyncio.sleep(3)

    # ==========================================
    # 2. PROCESAMIENTO TÉCNICO (Si se subió)
    # ==========================================
    if archivo_tecnico and archivo_tecnico.filename.endswith('.pdf'):
        try:
            doc_tec = pymupdf.open(stream=await archivo_tecnico.read(), filetype="pdf")
            texto_tecnico = "".join([pagina.get_text() for pagina in doc_tec])
            
            prompt_tec_listo = f"{PROMPT_TECNICO}\n\n--- TEXTO ESPECIFICACIÓN TÉCNICA ---\n{texto_tecnico}"
            res_tec = client.models.generate_content(model='gemini-3.5-flash', contents=prompt_tec_listo)
            
            json_tec_str = res_tec.text.split("```json")[1].split("```")[0] if "```json" in res_tec.text else res_tec.text
            match_tec = re.search(r'\{.*\}', json_tec_str, re.DOTALL)
            if match_tec:
                datos_finales.update(json.loads(match_tec.group(0)))
        except Exception as e:
            print(f"⚠️ Error procesando Especificación Técnica: {str(e)}")

    # Asegurarnos de que el frontend siempre reciba una lista de trabajos, aunque venga vacía
    if "trabajos_solicitados" not in datos_finales:
        datos_finales["trabajos_solicitados"] = []

    return datos_finales

@app.get("/")
def estado_servidor():
    return {"mensaje": "Backend de cotizaciones activo y funcionando."}

def calcular_similitud_coseno(vec1, vec2):
    v1, v2 = np.array(vec1), np.array(vec2)
    if np.linalg.norm(v1) == 0 or np.linalg.norm(v2) == 0: return 0.0
    return np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))


@app.post("/api/cotizar-sql")
async def cotizar_sql(datos: SolicitudCotizacion):
    try:
        # 1. Convertir el JSON de la IA a una tabla Pandas
        df_ia = pd.DataFrame(datos.trabajos)
        df_ia['Client_Item'] = pd.to_numeric(df_ia.get('Client_Item', 0), errors='coerce').fillna(0).astype(int)

        # 2. Conexión a SQL Server (Asegúrate de que tus credenciales en el .env estén bien)
        try:
            conn_str = (
                "DRIVER={ODBC Driver 17 for SQL Server};"
                f"SERVER={os.getenv('10.133.18.111')};"
                f"DATABASE={os.getenv('UPRATE')};"
                f"UID={os.getenv('p.ti')};"
                f"PWD={os.getenv('DesarrolloTng2026!')}"
            )
            conexion = pyodbc.connect(conn_str)
        except Exception as e:
            raise ValueError(f"Fallo al conectar con SQL Server: {str(e)}")

        # 3. La Consulta SQL adaptada a tus NUEVAS COLUMNAS
        query = """
            SELECT 
                item_id AS Client_Item, 
                description_en AS Descripcion_Matriz,
                base_mhrs, 
                base_material_usd, 
                base_freight_usd, 
                base_subcontract_usd,
                base_smr_usd
            FROM dbo.cat_uprate_items -- ⚠️ CAMBIA ESTO POR EL NOMBRE DE TU TABLA
            WHERE is_active = 1
        """
        df_tarifario = pd.read_sql(query, conexion)
        conexion.close()
        
        # Asegurar que el ID sea entero para el cruce
        df_tarifario['Client_Item'] = df_tarifario['Client_Item'].astype(int)
        
        # 4. EL CRUCE MAGNÍFICO
        df_cruzado = pd.merge(df_ia, df_tarifario, on='Client_Item', how='left')
        
        # 5. EL MOTOR MATEMÁTICO (Recreando las fórmulas de UPRATE)
        # Asegurar cantidad mínima de 1
        df_cruzado['Cant_Qty'] = pd.to_numeric(df_cruzado.get('Cant_Qty', 1), errors='coerce').fillna(1)
        
        # Variables Financieras (Basado en tu antiguo código)
        TARIFA_MANO_OBRA = 35.36
        MARGEN_UTILIDAD = 0.14
        
        # A) Calcular Costo Directo Unitario
        df_cruzado['Costo_Mano_Obra'] = df_cruzado['base_mhrs'] * TARIFA_MANO_OBRA
        df_cruzado['Costo_Directo_Total'] = (
            df_cruzado['Costo_Mano_Obra'] + 
            df_cruzado['base_material_usd'].fillna(0) + 
            df_cruzado['base_freight_usd'].fillna(0) + 
            df_cruzado['base_subcontract_usd'].fillna(0) +
            df_cruzado['base_smr_usd'].fillna(0)
        )
        
        # B) Calcular Utilidades y Precio Unitario (Tarifa)
        df_cruzado['Utilidad_Total'] = df_cruzado['Costo_Directo_Total'] * MARGEN_UTILIDAD
        df_cruzado['Precio_Tarifa'] = df_cruzado['Costo_Directo_Total'] + df_cruzado['Utilidad_Total']
        
        # C) Calcular Gran Total por Partida (Precio Tarifa * Cantidad que extrajo la IA)
        df_cruzado['Costo_Total_Calculado'] = df_cruzado['Precio_Tarifa'] * df_cruzado['Cant_Qty']
        
        # D) Validar si encontró el registro (Verde) o no existe en SQL (Rojo)
        df_cruzado['estado_validacion'] = df_cruzado['Costo_Directo_Total'].apply(lambda x: "Verde" if pd.notnull(x) else "Rojo")
        
        # Renombrar 'base_mhrs' a 'MHRS_UNIT' para que React lo entienda sin cambiar el Frontend
        df_cruzado.rename(columns={'base_mhrs': 'MHRS_UNIT'}, inplace=True)
        
        # Sumatoria final
        gran_total = float(df_cruzado['Costo_Total_Calculado'].sum())
        
        # Limpiar celdas vacías para JSON
        df_cruzado = df_cruzado.fillna('N/A')
        
        return {
            "gran_total": gran_total,
            "partidas": df_cruzado.to_dict(orient='records')
        }
        
    except Exception as e:
        import traceback
        print("\n=== ERROR EN CRUCE CON SQL SERVER ===")
        traceback.print_exc()
        print("======================================\n")
        raise HTTPException(status_code=500, detail=f"Error cruzando datos: {str(e)}")


#@app.post("/api/analizar-plano")
#async def analizar_plano(archivo_plano: UploadFile = File(...)):
    if not archivo_plano.filename.endswith('.pdf'):
        raise HTTPException(status_code=400, detail="El plano debe ser un PDF")
    try:
        doc = pymupdf.open(stream=await archivo_plano.read(), filetype="pdf")
        imagenes = [types.Part.from_bytes(data=p.get_pixmap(dpi=200).tobytes("jpeg"), mime_type="image/jpeg") for p in doc]
        prompt = """Eres ingeniero naval. Analiza este plano y extrae: {"nombre_embarcacion": "", "dimensiones": "", "revisiones_cliente": [], "espacios_clave": []} Devuelve SOLO el JSON."""
        response = client.models.generate_content(model='gemini-3.6-flash', contents=[prompt] + imagenes)
        return json.loads(re.search(r'\{.*\}', response.text, re.DOTALL).group(0))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

