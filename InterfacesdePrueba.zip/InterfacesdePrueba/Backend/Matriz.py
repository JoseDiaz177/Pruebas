import re

# ==========================================
# EXPERTO 1: LECTOR DEL RFQ (DATOS DEL BARCO)
# ==========================================
PROMPT_RFQ = """
Eres un estimador naval experto. Analiza ÚNICAMENTE el TEXTO RFQ proporcionado.
Extrae: cliente, proyecto, tipo, bandera, clase, localizacion, Dique asignado, eslora, manga y puntal. (Usa solo números para las medidas, si no hay dato pon 0).
"""

# ==========================================
# EXPERTO 2: LECTOR TÉCNICO (LISTA DE TRABAJOS)
# ==========================================
PROMPT_TECNICO = """
Eres un estimador naval experto. Analiza ÚNICAMENTE el TEXTO ESPECIFICACIÓN TÉCNICA proporcionado.

- PARA ESTA PRUEBA, CÉNTRATE ÚNICA Y EXCLUSIVAMENTE en la Sección 1000 (DOCKING AND SERVICE).
- Extrae OBLIGATORIAMENTE Y SOLO los ítems del 1001 al 1005. IGNORA absolutamente cualquier otro ítem.
- Extrae literalmente la descripción que viene en el documento para cada uno de esos 5 ítems.
- Para todos estos 5 trabajos, el valor de "GRUPO" siempre será "1".
- El "Client_Item" será su número correspondiente (1001, 1002, 1003, 1004 o 1005).

Devuelve tu respuesta ÚNICAMENTE como un JSON válido con esta estructura exacta:
{
    "trabajos_solicitados": [
        {
            "GRUPO": "1",
            "Client_Item": "1001",
            "Cant_Qty": 1,
            "Unidad_Unit": "USD",
            "Descripcion_Servicio": "Docking/undocking including first day, normal hrs, full day or part"
        }
    ]
}
"""

# 2. EL MOTOR DE CRUCE
def clasificar_servicio(desc_cliente, catalogo_uprate, dique_asignado):
    desc_lower = desc_cliente.lower()
    match = None
    
    if "valve" in desc_lower and "dn" in desc_lower:
        dn_match = re.search(r'dn\s*(\d+)', desc_lower)
        if dn_match:
            dn_original = int(dn_match.group(1))
            calibres_uprate = [25, 50, 75, 100, 125, 150, 200, 250, 300, 350, 400]
            dn_ajustado = min(calibres_uprate, key=lambda x: abs(x - dn_original))
            
            texto_busqueda = f"valve diam {dn_ajustado} mm"
            match = next((p for p in catalogo_uprate if texto_busqueda in p["desc"].lower()), None)
            if dn_ajustado <= 25 and not match:
                match = next((p for p in catalogo_uprate if "valve diam 25 mm" in p["desc"].lower()), None)

    elif "water hosing" in desc_lower or "wash" in desc_lower:
        if "fondo plano" in desc_lower or "bottom" in desc_lower:
            match = next((p for p in catalogo_uprate if "wash" in p["desc"].lower() and "bottom" in p["desc"].lower()), None)
        else: 
            match = next((p for p in catalogo_uprate if "wash" in p["desc"].lower() and "side" in p["desc"].lower()), None)
            
    elif "sistema epoxico" in desc_lower or "paint" in desc_lower or "pintura" in desc_lower:
        if "fondo plano" in desc_lower or "bottom" in desc_lower:
            match = next((p for p in catalogo_uprate if "full coat paint" in p["desc"].lower() and "bottom" in p["desc"].lower()), None)
        else: 
            match = next((p for p in catalogo_uprate if "full coat paint" in p["desc"].lower() and "side" in p["desc"].lower()), None)

    if match:
        id_partida = match["id"]
        descripcion_sql = match["desc"]
        precio_unitario = match["dd5"] if dique_asignado == "Dique 5" else match["dd2"]
        return id_partida, descripcion_sql, precio_unitario, "Verde"
        
    return "TBA", "Requiere cotización manual", 0.0, "Rojo"



