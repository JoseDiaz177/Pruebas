import os
import time
import json
from flask import Flask, jsonify, render_template, request
from werkzeug.utils import secure_filename
import pandas as pd
import numpy as np
from google import genai
from google.genai import types

app = Flask(__name__, template_folder='templates')
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

gemini_client = genai.Client(api_key="AQ.Ab8RN6KnNVa6jpmrxYiu6sdblVtmZdCHTyBx1DDk8R-CPp883w")
EXTENSIONES_PERMITIDAS = {'pdf', 'png', 'jpg', 'jpeg', 'csv', 'xlsx', 'xls'}

def archivo_permitido(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in EXTENSIONES_PERMITIDAS


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/procesar_documento', methods=['POST'])
def procesar_documento():
    if 'archivo' not in request.files:
        return jsonify({"error": "No se encontró el archivo"}), 400
    
    archivo = request.files['archivo']
    patron_usuario = request.form.get('patron', 'Encuentra las coincidencias de servicios.')
    
    if archivo.filename == '' or not archivo_permitido(archivo.filename):
        return jsonify({"error": "Archivo no válido"}), 400

    filename = secure_filename(archivo.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    archivo.save(filepath)
    ext = filename.rsplit('.', 1)[1].lower()

    try:
        # 1. LEER EXCEL MAESTRO DE FORMA SEGURA
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        excel_path = os.path.join(BASE_DIR, 'UPRATE_2026.xlsx')
        df_maestro = pd.read_excel(excel_path)
        df_maestro = df_maestro.fillna('')
        catalogo_texto = df_maestro.to_csv(index=False)

        # 2. Subir archivo del cliente a Gemini
        if ext in ['pdf', 'png', 'jpg', 'jpeg']:
            contenido_analisis = gemini_client.files.upload(file=filepath)
        elif ext in ['csv', 'xlsx', 'xls']:
            df_input = pd.read_csv(filepath) if ext == 'csv' else pd.read_excel(filepath)
            contenido_analisis = df_input.to_string(index=False)


# 3. PROMPT DELEGANTE Y ENTRENAMIENTO DE IA
        prompt = f"""
        Eres un estimador experto de un astillero y un analista de datos avanzado. 
        
        CATÁLOGO MAESTRO (CSV, xlsx, pdf, jpg, png):
        {catalogo_texto}
        
        DOCUMENTO DEL CLIENTE: 
        Analiza el archivo adjunto.
        
        INSTRUCCIÓN DEL USUARIO: "{patron_usuario}"
        
        METODOLOGÍA DE ANÁLISIS (TU ENTRENAMIENTO):
        1. Comprende la "Instrucción del usuario". Si el usuario te pide un rango específico (ej. "del 1000 al 1030"), condiciones especiales, o que ignores ciertos ítems, DEBES aplicar ese filtro antes de hacer cualquier cruce.
        2. Cruza únicamente la información solicitada con el Catálogo Maestro.
        3. Deduce inteligentemente qué columna del catálogo representa cada concepto. Haciendo los calculos correspondientes depende a lo que el usuario te pida.
        4. Deuelve salida de valores completos tomando en cuenta las especificaciones que te pida el usuario (Ej. dame los valores de la columna mhrs de toda la seccion 1000).
        
        REGLA DE SALIDA ESTRICTA:
        Sin importar lo que te pida el usuario, tu respuesta final debe ser ÚNICAMENTE un JSON válido con un arreglo de objetos. Cada objeto debe contener exactamente estas 25 llaves (si un dato no aplica o no existe tras tu análisis, pon un string vacío ""):
        [
          {{
            "grupo": "...",
            "desc_grupo": "...",
            "client_item": "...",
            "cant": 1.0,
            "unit": "...",
            "desc_servicio": "...",
            "mhrs": "...",
            "total_hh": "...",
            "total_mo": "...",
            "costo_mat": "...",
            "subcontratos": "...",
            "adicional": "...",
            "costo_directo_total": "...",
            "utilidad_mo": "...",
            "utilidad_mat": "...",
            "utilidad_sub": "...",
            "utilidad_adic": "...",
            "total_utilidad": "...",
            "servicios_incl": "...",
            "comision": "...",
            "costo_total": "...",
            "precio_total_usd": 0.0,
            "precios_ref": "...",
            "precio_unitario": "..."
          }}
        ]
        """
        
        # 4. SISTEMA DE REINTENTOS PARA ERRORES 503 DE LA API
        max_reintentos = 3
        response = None
        for intento in range(max_reintentos):
            try:
                response = gemini_client.models.generate_content(
                    model='gemini-3.6-flash',
                    contents=[contenido_analisis, prompt],
                    config=types.GenerateContentConfig(temperature=0.1, response_mime_type="application/json")
                )
                break
            except Exception as e:
                if "503" in str(e) and intento < max_reintentos - 1:
                    time.sleep(5)
                else:
                    raise e

        datos_cotizacion = json.loads(response.text)
        
        if ext in ['pdf', 'png', 'jpg', 'jpeg']:
            gemini_client.files.delete(name=contenido_analisis.name)
        os.remove(filepath)
        
        return jsonify(datos_cotizacion)

    except Exception as e:
        if os.path.exists(filepath): os.remove(filepath)
        return jsonify({"error": str(e)}), 500


@app.route('/api/chat', methods=['POST'])
def chat_ia():
    try:
        datos = request.json
        mensaje_usuario = datos.get('mensaje', '')
        
        # Leemos un fragmento del catálogo para que la IA tenga contexto al charlar
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        excel_path = os.path.join(BASE_DIR, '25R005 SCOT DESDEN Rev A.xlsx')
        
        contexto_catalogo = "Catálogo no disponible."
        if os.path.exists(excel_path):
            df_maestro = pd.read_excel(excel_path).fillna('')
            # Pasamos las primeras 30 filas al chat como memoria rápida
            contexto_catalogo = df_maestro.to_csv(index=False) 
            
        prompt = f"""
        Eres el asistente técnico de Inteligencia Artificial del 'Portal TNG', un sistema de cotizaciones para un astillero naval.
        Tu trabajo es asistir al estimador respondiendo sus dudas con claridad, haciendo presupuestos y tratando de ser lo mas exacto posible.
        
        AQUÍ TIENES UN FRAGMENTO DE LA MEMORIA DEL CATÁLOGO MAESTRO (CSV, xlsx, pdf, jpg, png):
        {contexto_catalogo}
        
        PREGUNTA DEL USUARIO: "{mensaje_usuario}"
        
        REGLAS PARA TU RESPUESTA:
        1. Sé profesional, directo y conciso .
        2. Si el usuario te pregunta por precios, tarifas o códigos, búscalo en el fragmento del catálogo que te compartí.
        3. Si la respuesta no está en el catálogo, indica educadamente que no tienes esa tarifa en tu contexto inmediato.
        4. Da un analisis en general al usuario, detalles, precios, todo depende lo que el usuario te pida y trata de ser lo mas exacto posible.
        """
        
        response = gemini_client.models.generate_content(
            model='gemini-3.6-flash',
            contents=[prompt],
            config=types.GenerateContentConfig(temperature=0.5) 
        )
        
        return jsonify({"respuesta": response.text})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)



